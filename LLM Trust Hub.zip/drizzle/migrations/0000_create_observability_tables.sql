CREATE TABLE public.teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  owner_email text NOT NULL
);
GRANT SELECT ON public.teams TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.teams TO authenticated;
GRANT ALL ON public.teams TO service_role;
ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read teams" ON public.teams FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.apps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  team_id uuid NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (name, team_id)
);
GRANT SELECT ON public.apps TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.apps TO authenticated;
GRANT ALL ON public.apps TO service_role;
ALTER TABLE public.apps ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read apps" ON public.apps FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX apps_team_id_idx ON public.apps(team_id);

CREATE TABLE public.eval_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id uuid NOT NULL REFERENCES public.apps(id) ON DELETE CASCADE,
  prompt text NOT NULL,
  response text NOT NULL,
  hallucination_score integer NOT NULL CHECK (hallucination_score BETWEEN 0 AND 100),
  relevance_score integer NOT NULL CHECK (relevance_score BETWEEN 0 AND 100),
  safety_score integer NOT NULL CHECK (safety_score BETWEEN 0 AND 100),
  trust_score numeric(5,2) NOT NULL CHECK (trust_score BETWEEN 0 AND 100),
  reasoning text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.eval_runs TO anon, authenticated;
GRANT INSERT ON public.eval_runs TO authenticated;
GRANT ALL ON public.eval_runs TO service_role;
ALTER TABLE public.eval_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read eval runs" ON public.eval_runs FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX eval_runs_app_created_idx ON public.eval_runs(app_id, created_at DESC);

CREATE TABLE public.experiments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id uuid NOT NULL REFERENCES public.apps(id) ON DELETE CASCADE,
  version_a_prompt text NOT NULL,
  version_a_response text NOT NULL,
  version_b_prompt text NOT NULL,
  version_b_response text NOT NULL,
  version_a_trust_score numeric(5,2) NOT NULL CHECK (version_a_trust_score BETWEEN 0 AND 100),
  version_b_trust_score numeric(5,2) NOT NULL CHECK (version_b_trust_score BETWEEN 0 AND 100),
  winner text NOT NULL CHECK (winner IN ('A', 'B', 'Tie')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.experiments TO anon, authenticated;
GRANT INSERT ON public.experiments TO authenticated;
GRANT ALL ON public.experiments TO service_role;
ALTER TABLE public.experiments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read experiments" ON public.experiments FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX experiments_app_created_idx ON public.experiments(app_id, created_at DESC);

CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id uuid NOT NULL REFERENCES public.apps(id) ON DELETE CASCADE,
  change_description text NOT NULL,
  eval_impact numeric(5,2),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_log TO anon, authenticated;
GRANT INSERT ON public.audit_log TO authenticated;
GRANT ALL ON public.audit_log TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read audit log" ON public.audit_log FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX audit_log_app_created_idx ON public.audit_log(app_id, created_at DESC);