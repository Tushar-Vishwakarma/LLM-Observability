# Live observability backend

## Goal
Keep the current website design while replacing its mock operational data with live Lovable Cloud records and working quality evaluation flows.

## Build
- Create secure tables for teams, applications, evaluation runs, experiments, and audit history, including realistic starter records.
- Add server-side data functions for dashboard summaries, application history, team scorecards, evaluations, experiments, and audit entries.
- Connect the organization dashboard to current and previous evaluation scores, with live team health totals and application trends.
- Add prompt/response evaluation to application pages, including progress, clear errors, scored badges, reasoning, and recent run history.
- Add live A/B comparison with two evaluations, winner calculation, score difference, persistence, and recent experiment results.
- Add a team selector, live owned-application scores, audit history, and a working “Log a change” form.
- Align glossary terminology with the stored score names.

## Security and reliability
- Keep model credentials server-side and validate every submitted field.
- Restrict direct database access; all writes and sensitive processing run through server functions.
- Test the data queries and end-to-end forms, including loading and error states.

## Required setup
Anthropic requires an API key from the Anthropic Console. Once the data layer and forms are ready, Lovable will request it through a secure field; it will never be placed in browser code.
