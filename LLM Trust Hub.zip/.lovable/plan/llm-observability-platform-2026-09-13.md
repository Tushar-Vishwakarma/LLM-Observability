# LLM Observability Platform

## Goal
Build a polished multi-page website for organization-wide LLM quality monitoring, experimentation, and governance. The experience will feel like a live enterprise product using realistic sample data across 500+ applications and 200+ teams.

## Pages
- **Home** — headline, dashboard call-to-action, organization stats, and three value pillars.
- **Dashboard** — organization summary, sortable application table, status indicators, trends, and links into app details.
- **App detail** — app identity and trust score, 30-day quality chart, metric breakdown, and recent alerts.
- **Metrics Glossary** — prominent Trustworthy Response Rate definition plus seven supporting metric cards with targets, roll-up logic, and owners.
- **Experiments** — Version A/B comparison, traffic allocation, confidence result, rollout control, and auto-pause setting.
- **Team Scorecard** — owned apps, editable alert thresholds, and audit history.

## Design
- Google-inspired visual language with bright white surfaces, cool greys, one confident blue accent, generous spacing, subtle elevation, and restrained rounded corners.
- Clean sans-serif typography, compact data presentation, accessible contrast, and responsive layouts for desktop and mobile.
- Shared navigation and consistent status, metric, table, chart, badge, and control patterns across pages.

## Technical details
- Create a shared site header and reusable UI/data components while keeping every major section on its own route.
- Use lightweight SVG/CSS charts and native React state for sorting, sliders, toggles, and editable thresholds.
- Add unique search and sharing metadata to every page.
- Verify navigation, controls, desktop layout, mobile layout, and current preview diagnostics.
