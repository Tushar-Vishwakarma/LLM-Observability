import { Link } from "@tanstack/react-router";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Beaker,
  BookOpen,
  Boxes,
  CircleAlert,
  CircleCheck,
  Gauge,
  Menu,
  ShieldCheck,
  Users,
  X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";

export const apps = [
  { id: "support-copilot", name: "Support Copilot", team: "Customer Experience", trr: 97.8, trend: 1.4, evaluated: "8 min ago", calls: "1.8M" },
  { id: "policy-assistant", name: "Policy Assistant", team: "Legal Operations", trr: 96.4, trend: 0.6, evaluated: "14 min ago", calls: "482K" },
  { id: "sales-insight", name: "Sales Insight", team: "Revenue Intelligence", trr: 94.2, trend: -1.8, evaluated: "21 min ago", calls: "796K" },
  { id: "code-reviewer", name: "Code Reviewer", team: "Developer Platform", trr: 98.1, trend: 0.9, evaluated: "28 min ago", calls: "2.3M" },
  { id: "claims-navigator", name: "Claims Navigator", team: "Insurance Products", trr: 92.7, trend: -2.3, evaluated: "34 min ago", calls: "641K" },
  { id: "research-summarizer", name: "Research Summarizer", team: "Knowledge Systems", trr: 95.6, trend: 0.3, evaluated: "41 min ago", calls: "354K" },
  { id: "finance-analyst", name: "Finance Analyst", team: "Finance Automation", trr: 96.9, trend: 1.1, evaluated: "52 min ago", calls: "218K" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const nav = [
    ["Home", "/"],
    ["Dashboard", "/dashboard"],
    ["Metrics Glossary", "/metrics"],
    ["Experiments", "/experiments"],
    ["Team Scorecard", "/team-scorecard"],
  ] as const;

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 lg:px-8">
        <Link to="/" className="flex items-center gap-2.5 font-semibold text-foreground">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm"><Gauge className="size-4" /></span>
          <span className="hidden sm:inline">LLM Observability</span>
          <span className="sm:hidden">LLM Observe</span>
        </Link>
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main navigation">
          {nav.map(([label, to]) => (
            <Link key={to} to={to} activeOptions={{ exact: to === "/" }} className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground data-[status=active]:bg-accent data-[status=active]:text-primary">
              {label}
            </Link>
          ))}
        </nav>
        <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(!open)} aria-label={open ? "Close navigation" : "Open navigation"}>
          {open ? <X /> : <Menu />}
        </Button>
      </div>
      {open && (
        <nav className="border-t border-border bg-background px-5 py-3 lg:hidden" aria-label="Mobile navigation">
          {nav.map(([label, to]) => <Link key={to} to={to} onClick={() => setOpen(false)} className="block rounded-md px-3 py-3 text-sm font-medium text-muted-foreground data-[status=active]:bg-accent data-[status=active]:text-primary">{label}</Link>)}
        </nav>
      )}
    </header>
  );
}

export function PageHeader({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col gap-5 border-b border-border pb-7 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-3xl">
        {eyebrow && <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-primary">{eyebrow}</p>}
        <h1 className="font-display text-3xl font-semibold text-foreground sm:text-4xl">{title}</h1>
        {description && <p className="mt-3 max-w-2xl text-base leading-7 text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function MetricCard({ label, value, detail, tone = "default" }: { label: string; value: string; detail: string; tone?: "default" | "positive" | "warning" }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-card">
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className={`mt-3 font-display text-3xl font-semibold ${tone === "positive" ? "text-success" : tone === "warning" ? "text-warning" : "text-foreground"}`}>{value}</p>
      <p className="mt-2 text-xs text-muted-foreground">{detail}</p>
    </div>
  );
}

export function StatusBadge({ score }: { score: number }) {
  const good = score >= 95;
  const risk = score < 93;
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${good ? "bg-success-soft text-success" : risk ? "bg-danger-soft text-danger" : "bg-warning-soft text-warning"}`}><span className="size-1.5 rounded-full bg-current" />{good ? "Healthy" : risk ? "At risk" : "Watch"}</span>;
}

export function Trend({ value }: { value: number }) {
  const up = value >= 0;
  return <span className={`inline-flex items-center gap-1 text-sm font-medium ${up ? "text-success" : "text-danger"}`}>{up ? <ArrowUpRight className="size-4" /> : <ArrowDownRight className="size-4" />}{Math.abs(value).toFixed(1)}%</span>;
}

export function LineChart({ values = [94.1, 94.7, 94.4, 95.2, 95.6, 95.1, 96.2, 96.5, 96.1, 97.0, 96.8, 97.8] }: { values?: number[] }) {
  const min = Math.min(...values) - 1;
  const max = Math.max(...values) + 1;
  const points = values.map((v, i) => `${(i / (values.length - 1)) * 100},${100 - ((v - min) / (max - min)) * 82 - 8}`).join(" ");
  const area = `0,100 ${points} 100,100`;
  return (
    <div className="relative h-64 w-full overflow-hidden" aria-label="Trustworthy response rate trend chart">
      <div className="absolute inset-0 flex flex-col justify-between py-3">
        {[98, 96, 94, 92].map(v => <div key={v} className="flex items-center gap-3"><span className="w-7 text-right text-xs text-muted-foreground">{v}</span><span className="h-px flex-1 bg-border" /></div>)}
      </div>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-y-3 left-10 h-[calc(100%-1.5rem)] w-[calc(100%-2.5rem)] overflow-visible">
        <polygon points={area} className="fill-primary-soft" />
        <polyline points={points} fill="none" vectorEffect="non-scaling-stroke" className="stroke-primary" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <div className="absolute bottom-0 left-10 right-0 flex justify-between text-xs text-muted-foreground"><span>Aug 15</span><span>Aug 22</span><span>Aug 29</span><span>Sep 13</span></div>
    </div>
  );
}

export const valueProps = [
  { icon: Gauge, title: "Data-Driven Insights", text: "A shared quality language across every model, provider, and product surface." },
  { icon: Beaker, title: "Live Experimentation", text: "Compare prompts and models with confidence before changes reach everyone." },
  { icon: Users, title: "Team Ownership", text: "Clear thresholds, accountable owners, and audit-ready governance by default." },
];

export const glossaryIcons = { ShieldCheck, CircleCheck, CircleAlert, Boxes, BookOpen, Gauge, Users };

export function ArrowLink({ to, children }: { to: "/dashboard" | "/metrics" | "/experiments" | "/team-scorecard"; children: ReactNode }) {
  return <Link to={to} className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">{children}<ArrowRight className="size-4" /></Link>;
}